import { JsonPipe } from '@angular/common';
import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { ReactiveFormsModule, FormGroup, FormBuilder,Validators } from '@angular/forms';
@Component({
  selector: 'app-reactive-forms',
  standalone: true,
  imports: [ReactiveFormsModule,JsonPipe],
  templateUrl: './reactiveForms.component.html',
  styles: `
    :host {
      display: block;
    }
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export default class ReactiveFormsComponent { 
  formRegister!: FormGroup;
  private Fb=inject(FormBuilder);
  constructor(){
    this.formRegister=this.Fb.group({
      nombre: ['Alejandro',[Validators.required,Validators.minLength(3)]],
      password:['1234',[Validators.required,Validators.minLength(8)]],
      email:['oeo@gmail.com',Validators.required]
    });
  }
}
