import { ChangeDetectionStrategy, Component } from '@angular/core';

@Component({
  selector: 'app-examen1p',
  standalone: true,
  imports: [],
  templateUrl: './examen1p.component.html',
  styles: `
    :host {
      display: block;
    }
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export default class Examen1pComponent { }
